package com.acs.studentDetails.daoImpl;

import com.acs.studentDetails.dao.StudentDao;
import com.acs.studentDetails.model.Student;
import com.acs.studentDetails.util.StudentDatabaseConnection;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

public class StudentDaoImpl implements StudentDao {
    @Override
    public void save(Student student) {

        Transaction transaction = null;
        try (Session session = StudentDatabaseConnection.getSessionFactory().openSession()) {
            // start a transaction
            transaction = session.beginTransaction();
            // save the student object
            session.save(student);
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }

    }
}
