package com.acs.studentDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
